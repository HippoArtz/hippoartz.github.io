Put your web-sized JPGs/PNGs in this folder and update the filenames in index.html.

Recommended:
- Long side ~2000px
- JPEG at 80–85% quality
- Filenames: use-kebabs-like-this.jpg (no spaces)
